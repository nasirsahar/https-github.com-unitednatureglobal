# Unitednaturesustainabilityfoundation

Create a website for United Nature Sustainability Foundation  with all pages like About Us, Services, Thematic areas , contact us, gallery , .... It must be world class website

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://unitednaturesustainabilityfoundation.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/26df1414-1a05-4297-92ab-c15f0663fb62).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
