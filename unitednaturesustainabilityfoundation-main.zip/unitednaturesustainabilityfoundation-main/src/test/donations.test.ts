import { describe, expect, it } from "vitest";
import { donationPaymentUrl, donationUpiId } from "../lib/donations";

describe("donation payment recipient", () => {
  it("uses the user-supplied UPI ID for payment", () => {
    expect(donationUpiId).toBe("8076018169-2@ybl");
    expect(new URL(donationPaymentUrl).searchParams.get("pa")).toBe("8076018169-2@ybl");
  });
});