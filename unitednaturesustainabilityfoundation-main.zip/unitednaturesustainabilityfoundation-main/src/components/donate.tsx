import { useState } from "react";
import { Check, Copy, Heart, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import qrAsset from "@/assets/donation-qr.png.asset.json";
import { donationPaymentUrl, donationUpiId } from "@/lib/donations";

export function DonateButton() {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  async function copyUpi() {
    try {
      await navigator.clipboard.writeText(donationUpiId);
      setCopied(true);
      setCopyError(false);
    } catch {
      setCopyError(true);
    }
  }
  return (
    <Dialog onOpenChange={() => { setCopied(false); setCopyError(false); }}>
      <DialogTrigger asChild><Button className="h-11 rounded-full px-5"><Heart />Donate</Button></DialogTrigger>
      <DialogContent className="max-h-[90dvh] w-[calc(100%-2rem)] max-w-lg overflow-y-auto rounded-lg">
        <DialogHeader>
          <DialogTitle className="pr-6 font-display text-2xl">Donate to United Nature</DialogTitle>
          <DialogDescription>United Nature Sustainability Foundation</DialogDescription>
        </DialogHeader>
        <img src={qrAsset.url} alt="PhonePe payment QR for United Nature Sustainability Foundation" className="mx-auto w-full max-w-[260px] rounded-lg" />
        <div className="border-y py-4">
          <p className="text-xs font-semibold uppercase text-muted-foreground">UPI ID</p>
          <div className="mt-2 flex items-center justify-between gap-2">
            <span className="break-all font-semibold text-primary">{donationUpiId}</span>
            <Button variant="outline" size="icon" onClick={copyUpi} aria-label={copied ? "UPI ID copied" : "Copy UPI ID"} title="Copy UPI ID">{copied ? <Check /> : <Copy />}</Button>
          </div>
          <p role="status" className="mt-1 text-sm text-muted-foreground">{copied ? "UPI ID copied" : copyError ? "Please select and copy the UPI ID above." : ""}</p>
        </div>
        <Button asChild size="lg"><a href={donationPaymentUrl}><Smartphone />Donate via UPI</a></Button>
        <div>
          <h3 className="text-lg">Bank transfer</h3>
          <a href="mailto:nasirsahar@gmail.com?subject=Donation%20bank%20details" className="text-sm text-primary underline underline-offset-4">Request bank account details</a>
        </div>
      </DialogContent>
    </Dialog>
  );
}