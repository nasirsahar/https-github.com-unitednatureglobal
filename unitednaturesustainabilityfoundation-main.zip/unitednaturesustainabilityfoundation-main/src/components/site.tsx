import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { Menu, X, Mail, Phone, MapPin } from "lucide-react";
import logoAsset from "../assets/united-nature-logo.png.asset.json";
import { DonateButton } from "./donate";

const logo = logoAsset.url;

const nav = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About Us" },
  { to: "/services", label: "Services" },
  { to: "/thematic-areas", label: "Thematic Areas" },
  { to: "/legality", label: "Legality" },
  { to: "/gallery", label: "Gallery" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50">
      <div className="bg-deep text-deep-foreground">
        <div className="mx-auto flex max-w-7xl flex-wrap items-baseline justify-between gap-x-6 gap-y-1 px-5 py-3">
          <p className="font-display text-base font-semibold uppercase tracking-[0.12em] md:text-lg">
            United Nature Sustainability Foundation
          </p>
          <p className="text-[11px] uppercase tracking-[0.22em] opacity-75 md:text-xs">
            Delhi&nbsp;·&nbsp;General Development
          </p>
        </div>
      </div>
      <div className="border-b bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">

        <Link to="/" className="flex items-center gap-2.5">
          <img src={logo} alt="United Nature logo" className="h-11 w-11 rounded-full ring-1 ring-border" />
          <span className="leading-tight">
            <span className="block font-display text-xl font-extrabold uppercase tracking-wide text-primary">United Nature</span>
            <span className="block text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Sustainability Foundation</span>
          </span>
        </Link>
        <nav className="hidden items-center gap-6 lg:flex">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="text-sm font-medium text-muted-foreground hover:text-foreground" activeProps={{ className: "text-sm font-semibold text-primary" }} activeOptions={{ exact: true }}>
              {n.label}
            </Link>
          ))}
          <DonateButton />
        </nav>
        <button className="lg:hidden" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav className="flex flex-col gap-1 border-t px-5 py-4 lg:hidden">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="rounded-lg px-3 py-3 font-medium hover:bg-muted">
              {n.label}
            </Link>
          ))}
          <div className="px-3 py-2"><DonateButton /></div>
        </nav>
      )}
      </div>
    </header>

  );
}

export function Footer() {
  return (
    <footer className="bg-deep text-deep-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <img src={logo} alt="United Nature logo" className="mb-6 h-20 w-20" />
          <h3 className="text-3xl">Restoring nature. <span className="text-bright italic">Uplifting people.</span></h3>
          <p className="mt-4 max-w-md opacity-75">United Nature Sustainability Foundation works with communities to protect ecosystems, build climate resilience and create sustainable livelihoods.</p>
          <div className="mt-6"><DonateButton /></div>
        </div>
        <div>
          <h4 className="mb-4 text-lg">Explore</h4>
          <ul className="space-y-2 opacity-80">
            {nav.map((n) => <li key={n.to}><Link to={n.to} className="hover:text-bright">{n.label}</Link></li>)}
          </ul>
        </div>
        <div>
          <h4 className="mb-4 text-lg">Reach us</h4>
          <ul className="space-y-3 opacity-80">
            <li className="flex gap-2"><Mail className="h-4 w-4 mt-1 shrink-0" /> nasirsahar@gmail.com</li>
            <li className="flex gap-2"><Phone className="h-4 w-4 mt-1 shrink-0" /> +91 80760 18169</li>
            <li className="flex gap-2"><MapPin className="h-4 w-4 mt-1 shrink-0" /> House No. 306, Kh No. 27/9, 2nd Floor, Blk-A, Meer Vihar, Mangal Bazar, Delhi – 110081</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-deep-foreground/15 py-6 text-center text-sm opacity-60">
        © {new Date().getFullYear()} United Nature Sustainability Foundation. All rights reserved.
      </div>
    </footer>
  );
}

export function PageHero({ eyebrow, title, text, image, compact }: { eyebrow: string; title: ReactNode; text: string; image: string; compact?: boolean }) {
  return (
    <section className="relative isolate overflow-hidden">
      <img src={image} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover" />
      <div className="hero-overlay absolute inset-0 -z-10" />
      <div className={`mx-auto max-w-7xl px-5 text-deep-foreground ${compact ? "py-14 md:py-20" : "py-28 md:py-36"}`}>

        <p className="text-xs font-bold uppercase tracking-[0.25em] text-bright">{eyebrow}</p>
        <h1 className="mt-4 max-w-3xl text-4xl leading-tight md:text-6xl">{title}</h1>
        <p className="mt-5 max-w-2xl text-lg opacity-85">{text}</p>
      </div>
    </section>
  );
}

export function CTA() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-20">
      <div className="rounded-[2rem] bg-primary px-8 py-14 text-center text-primary-foreground shadow-soft md:px-16">
        <h2 className="text-3xl md:text-5xl">Be part of the change.</h2>
        <p className="mx-auto mt-4 max-w-xl opacity-85">Volunteer, partner or donate — every action helps restore our planet.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link to="/contact" className="btn-bright">Partner with us</Link>
          <Link to="/thematic-areas" className="btn-ghost-light">Our work</Link>
        </div>
      </div>
    </section>
  );
}

export function meta(title: string, description: string) {
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "keywords", content: "United Nature Sustainability Foundation, unitednaturesustainabilityfoundation, UNSF, United Nature, NGO India, FPO consulting, CSR" },
    ],
    scripts: [{ type: "application/ld+json", children: JSON.stringify({ "@context": "https://schema.org", "@type": "NGO", name: "United Nature Sustainability Foundation", alternateName: ["UNSF", "unitednaturesustainabilityfoundation"], url: "https://nature-sanctuary-net.lovable.app", email: "nasirsahar@gmail.com", telephone: "+91-8076018169", address: { "@type": "PostalAddress", streetAddress: "House No. 306, Kh No. 27/9, 2nd Floor, Blk-A, Meer Vihar", addressLocality: "Delhi", postalCode: "110081", addressCountry: "IN" } }) }],
  };
}
