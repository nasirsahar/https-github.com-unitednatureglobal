export const donationUpiId = "8076018169-2@ybl";
export const donationPayee = "UNITED NATURE SUSTAINABILITY FOUNDATION";
export const donationPaymentUrl = `upi://pay?pa=${encodeURIComponent(donationUpiId)}&pn=${encodeURIComponent(donationPayee)}&cu=INR`;