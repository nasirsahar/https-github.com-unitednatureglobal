import {
  Users, ClipboardList, SearchCheck, Presentation, Handshake, Landmark, Leaf,
  Sprout, Droplets, BookOpen, HeartHandshake, Settings, TrendingUp, Wheat,
  ShieldCheck, Store, IndianRupee, Globe, GraduationCap, Building2,
} from "lucide-react";

import nicoPhoto from "@/assets/advisor-nico-van-oudenhoven.jpg.asset.json";
import avinashPhoto from "@/assets/advisor-avinash-kumar.jpg.asset.json";
import madhuriPhoto from "@/assets/advisor-madhuri-gupta.jpg.asset.json";
import jayashreePhoto from "@/assets/advisor-jayashree-jayaraman.jpg.asset.json";
import ashutoshPhoto from "@/assets/advisor-ashutosh-srivastava.jpg.asset.json";
import ruchiPhoto from "@/assets/advisor-ruchi-saxena.jpg.asset.json";
import amartyaPhoto from "@/assets/amartya-sen.jpg.asset.json";
import frameworkPhoto from "@/assets/sustainability-framework.jpg.asset.json";
import unityPhoto from "@/assets/unity-logo.jpg.asset.json";
import sdgPhoto from "@/assets/sdg-wheel.jpg.asset.json";
import fieldPhoto from "@/assets/field-farming.jpg.asset.json";

export const photos = {
  framework: frameworkPhoto.url,
  unity: unityPhoto.url,
  sdgWheel: sdgPhoto.url,
  field: fieldPhoto.url,
  amartyaSen: amartyaPhoto.url,
};

export const contact = {
  name: "Nasiruddin Nasir",
  role: "Managing Director",
  phone: "+91 80760 18169",
  phoneHref: "tel:+918076018169",
  email: "nasirsahar@gmail.com",
  orgEmail: "Unitednature2021@gmail.com",
  website: "www.unindia.org",
  address: "House No. 306, Kh No. 27/9, 2nd Floor, Blk-A, Meer Vihar, Landmark: Mangal Bazar, Delhi – 110081, India",
  addressShort: "House No. 306, Khasra No. 27/9, Block A, Mangal Bazar Road, Meer Vihar Colony, New Delhi – 110081",
};

export const services = [
  { icon: Users, title: "Consulting", text: "Strategic advice for sustainable and scalable solutions." },
  { icon: ClipboardList, title: "Project Management", text: "End-to-end program and project cycle management." },
  { icon: SearchCheck, title: "Research, Evaluation & Impact Assessment", text: "Evidence for better decisions and greater impact." },
  { icon: Presentation, title: "Training & Capacity Building", text: "Skills for long-term change." },
  { icon: Handshake, title: "Business Development", text: "Partnerships, funding and growth opportunities." },
  { icon: Landmark, title: "Policy & Government Advisory", text: "Policy research, program design and implementation support." },
  { icon: Leaf, title: "CSR & Sustainability Support", text: "Facilitation and implementation of CSR and sustainability initiatives." },
];

export const expertise = [
  "Research and Studies",
  "Evaluation, Feasibility and Impact Assessment",
  "Nonprofits, Grant and Program Management",
  "Government, Public and Social Sector Consulting",
  "Corporate Social Investment (CSI)",
  "Corporate Social Responsibility (CSR)",
  "Social Development and Capacity Building",
  "Rural Development, Agriculture and Livelihood",
  "Inclusive Urban Development and Sustainable Cities",
  "Emergency Relief, Aid and Fundraising",
  "Responsible Business Practice",
  "Specialized Human Resources Services",
];

export const fpoServices = [
  { icon: Users, title: "New FPO Registration & Formation", points: ["Guidance on legal structure (Producer Company / Society)", "Documentation and compliance support", "Mobilization and capacity building of farmer members"] },
  { icon: ShieldCheck, title: "Compliance & Audit Support", points: ["Statutory and regulatory compliance (ROC, MCA, etc.)", "Internal and external audits", "Governance and record maintenance"] },
  { icon: Store, title: "Market Linkages & Value Chain Development", points: ["Buyer–seller connect and aggregation support", "Branding, packaging and market access", "Value addition and post-harvest management"] },
  { icon: IndianRupee, title: "Financial Linkages & Growth", points: ["Credit and working capital facilitation", "Access to government schemes and subsidies", "Financial planning and business development support"] },
  { icon: HeartHandshake, title: "CSR Partnerships", points: ["Connect with corporates for CSR support", "Project design and proposal development", "Implementation and monitoring support"] },
  { icon: Globe, title: "International Development Partnerships", points: ["Donor and development agency linkages", "Access to global best practices and funding", "Project collaboration and technical support"] },
  { icon: GraduationCap, title: "Training & Capacity Building", points: ["Leadership, governance and management training", "Technical and agribusiness skills", "Exposure visits and field demonstrations"] },
  { icon: Sprout, title: "Overall FPO Development", points: ["Business planning and strategy", "Institutional strengthening and governance", "Monitoring, evaluation and impact assessment"] },
];

export const whyChooseUs = [
  "Deep understanding of FPO ecosystem and rural markets",
  "Experienced team with development sector expertise",
  "Strong network with government, corporates, donors and market players",
  "Customized, practical and result-oriented approach",
  "Focus on inclusive, sustainable and scalable growth",
];

export const thematicAreas = [
  { icon: Leaf, title: "Environment & Natural Resource Management", text: "Conservation, climate resilience, watersheds, soil & water management, biodiversity." },
  { icon: Handshake, title: "Livelihoods & Enterprise", text: "Sustainable agriculture, value chains, rural development, food security, green jobs." },
  { icon: Wheat, title: "Agriculture and Rural Development", text: "Farmer-centric solutions, climate-resilient agriculture." },
  { icon: Droplets, title: "Water, Sanitation & Hygiene (WaSH)", text: "Safe water, sanitation, hygiene and WASH infrastructure and behaviour change." },
  { icon: BookOpen, title: "Education & Capacity Building", text: "Knowledge systems, skills development, institutional strengthening." },
  { icon: Users, title: "Gender and Inclusion", text: "Inclusive and equitable development." },
  { icon: Settings, title: "Policy & Governance", text: "Strengthening systems, multi-stakeholder collaboration." },
  { icon: TrendingUp, title: "Research, Evaluation & Impact", text: "Baseline, endline, impact assessments, monitoring, learning and reporting." },
];

export const registrations = [
  { icon: Building2, title: "Section 8 Company Registration", authority: "Ministry of Corporate Affairs (MCA)", text: "Registered under the Ministry of Corporate Affairs as a Section 8 not-for-profit company under the Companies Act, 2013. CIN: U85300DL2021NPL378749, RoC Delhi. Incorporated on 17 March 2021." },
  { icon: Landmark, title: "12A Registration", authority: "Income Tax Department, Govt. of India", text: "Registered under Section 12A of the Income Tax Act, 1961, recognising the Foundation as a not-for-profit entity whose income is exempt from tax." },
  { icon: Landmark, title: "80G Certification", authority: "Income Tax Department, Govt. of India", text: "Certified under Section 80G of the Income Tax Act, enabling donors to claim tax deduction on eligible contributions." },
  { icon: Building2, title: "CSR-1 Registration", authority: "Ministry of Corporate Affairs (MCA)", text: "Registered with MCA through Form CSR-1, making the Foundation eligible to implement CSR projects for companies under Section 135 of the Companies Act, 2013." },
  { icon: ClipboardList, title: "NGO Darpan", authority: "NITI Aayog, Govt. of India", text: "Enrolled on the NGO Darpan portal of NITI Aayog, enabling partnership with government ministries and departments." },
  { icon: Store, title: "UDYAM (MSME)", authority: "Ministry of Micro, Small & Medium Enterprises", text: "Registered on the UDYAM portal of the Ministry of MSME." },
  { icon: ShieldCheck, title: "GeM", authority: "Government e-Marketplace", text: "Registered on the Government e-Marketplace (GeM) to provide services to government buyers through transparent procurement." },
  { icon: SearchCheck, title: "GuideStar India", authority: "Transparency. Trust. Greater Impact.", text: "Listed on GuideStar India, India's largest repository of verified NGO information, reflecting our commitment to transparency." },
];

export const registrationFacts = [
  { label: "Registration No.", value: "378749" },
  { label: "Corporate Identification Number (CIN)", value: "U85300DL2021NPL378749" },
  { label: "Act & Authority", value: "Section 8 (Companies Act 2013), Ministry of Corporate Affairs — RoC Delhi, incorporated 17 March 2021" },
  { label: "Type of organisation", value: "Non-profit / Non-Government Company" },
  { label: "Income Tax registration under Section 12A", value: "Registered" },
  { label: "Income Tax registration under Section 80G", value: "Registered — donations are 50% tax exempt" },
  { label: "CSR-1 registration", value: "Registered" },
  { label: "MSME Udyam Registration No.", value: "UDYAM-DL-06-0117760" },
  { label: "GuideStar India (GSN) No.", value: "GSN14586" },
  { label: "NGO-Darpan", value: "DL/2024/0386919" },
  { label: "E-Anudaan", value: "Registered — Ministry of Social Justice and Empowerment" },
  { label: "Government e-Marketplace (GeM Seller ID)", value: "MPA9240011596119" },
  { label: "PAN", value: "Available on request" },
  { label: "Registered address", value: contact.addressShort },
  { label: "City / State", value: "New Delhi / Delhi" },
  { label: "Telephone & Mobile", value: "+91 8076018169" },
  { label: "E-mail", value: contact.orgEmail },
  { label: "Website", value: contact.website },
];

/* ---------------------------------- About Us --------------------------------- */

export const aboutIntro = {
  lead: "United Nature is one of India's foremost non-profit private sector companies with a core vision and commitment to build sustainable communities, economies and environment for 'Our Common Future'. With pan India presence and global networks, United Nature is working on multiple development themes with diverse stakeholders.",
  commitment: "United Nature is committed to Building a Better World Free of Poverty where everyone is happy, prosperous and peaceful in harmony with nature, instituted on principles of inclusivity, equality, resiliency and sustainability.",
  incorporation: "United Nature (with its legal name – United Nature Sustainability Foundation) was incorporated on 17 March 2021 as a non-profit company under Section 8 of the Companies Act, 2013 with the Government of India's central Ministry of Corporate Affairs, with its registered office in New Delhi.",
  approvals: "It is approved under Section 80G of the Income Tax Act to accept donations which are 50% tax exempted, and under Section 12A, which exempts its income from tax. It holds a CSR-1 certificate from the Ministry of Corporate Affairs that permits it to undertake CSR activities. It is empanelled with other Government of India platforms such as NITI Aayog – NGO Darpan, GuideStar India, Government e-Marketplace (GeM), Udyam (Ministry of MSME) and E-Anudaan (Ministry of Social Justice and Empowerment).",
};

export const aboutProfile = [
  "United Nature, as a national development agency, focuses on sustainability and corporate social responsibility. We specialise in consultation, implementation, capacity building, research and development for the private, public and social sectors' development and missions. Our purpose is to collaborate with stakeholders to achieve national development goals. Our end-to-end support to clients and partners includes developing policies, programs and strategic plans and in-house implementation — including handling and management of technical reports, information management systems (MIS dashboards), research and feasibility studies, baseline/end-line impact assessments and validation, social, economic and environmental audits — while simultaneously ensuring all legal compliance. Our services include engaging, empowering and building the capacity of individuals, grassroots organisations, communities and stakeholders.",
  "We work on multi-thematic areas such as sustainability, education, environment, health, poverty, water sanitation and hygiene (WASH), energy, agriculture, nutrition and food security, climate mitigation, emergency management, disaster and relief, community development, urban and rural development, social entrepreneurship, skill and livelihood development, gender inclusion, equality and women empowerment, sports and culture, social sustainability, social inclusion, protection and vulnerability, social development, sustainable development goals (SDGs), infrastructure and safe migration, among others. We plan and implement effective initiatives across geographies with targeted communities in collaboration with relevant stakeholders to deliver impact.",
  "We offer Board-to-Field tailored CSR and sustainability services employing a life-cycle approach that encompasses situational analysis, planning, implementation, reporting, impact assessment and compliance. Our services include advising on CSR policy and strategy development, designing and conducting socioeconomic surveys, baseline and need assessment, designing and implementing CSR initiatives, monitoring and evaluation, and environment and social governance (ESG) audits, which include sustainability reporting. Our primary focus is to promote community-led inclusive development, impact and sustainability through participation and ownership.",
  "United Nature is committed to strengthening the efforts and processes of partners, stakeholders and communities to bring measurable socio-economic empowerment through a 'Result Based Management (RBM)' approach that creates sustainable impacts. Our work is integrated with processes towards the sustainability goals of stakeholders by promoting actions that harmonise and strengthen equilibrium between societies, economic organisations and the environment, with prioritisation of the best interest of excluded and marginalised communities towards bringing social justice, equity and sustainable development.",
];

export const inspiration = {
  name: "Amartya Sen",
  caption: "Nobel Laureate Economist and Philosopher · 'The Conscience of Economics'",
  photo: photos.amartyaSen,
  paragraphs: [
    "Amartya Sen, a Nobel Laureate Economist and Philosopher known as 'The Conscience of Economics', is Emeritus Professor of Philosophy and Economics at Harvard and Cambridge Universities, and was listed among the world's 100 most influential people in 2010 by Time Magazine. He is a beacon of inspiration and guidance for many like us, and we constantly draw inspiration from him to work towards sustainability — finding ways to create a balance between social, economic and ecological well-being towards Building a Better World.",
    "Sen's profound insights into welfare economics, social justice and human development have paved the way for a more holistic approach to addressing global challenges. His pioneering work on the Capability Approach underscores the importance of focusing on people's capabilities and freedoms, aligning closely with the principles of sustainability that seek to ensure the well-being of current and future generations.",
    "Sustainability, according to Amartya Sen, could be understood as the ability of current generations to meet their needs without compromising the ability of future generations to meet their own needs. His focus on human capabilities and freedoms suggests that sustainability goes beyond environmental concerns and encompasses social, economic and political dimensions as well. In his view, a sustainable society not only preserves natural resources and ecosystems but also ensures that all individuals have the opportunity to lead fulfilling and dignified lives.",
    "As we embark on our journey towards sustainability, we look to Amartya Sen as a guiding light, inspiring us to work tirelessly towards a future that is inclusive, resilient and sustainable for all.",
  ],
  definition: "The definition of sustainability as 'meeting the needs of the present without compromising the ability of future generations to meet their own needs' is attributed to the World Commission on Environment and Development in its 1987 report 'Our Common Future', also known as the Brundtland Report, chaired by Gro Harlem Brundtland, former Prime Minister of Norway.",
};

export const vision = "United Nature envisions a future of sustainability with an inclusive, resilient, equitable and poverty-free world where everyone is happy, prosperous and peaceful while living harmoniously with the environment.";

export const mission = [
  "We are on a mission to build capacity and facilitate stakeholders' processes for social, economic and environmental stewardship, simultaneously empowering marginalised and excluded communities through transformative interventions as an integral part of sustainability goals, and to contribute to the creation of a greener, more prosperous and equitable world.",
  "United Nature participates in the processes of stakeholders while sustaining its effort to eradicate extreme poverty and maximise development impact by executing strategies in a result-based manner, facilitating policy dialogues, providing advisory services, and mobilising necessary resources through partnerships and multi-stakeholder engagements.",
];

export const coreValues = [
  { title: "Trusteeship", text: "As professional managers, we are conscious that United Nature has been given to us in 'trust' by all our stakeholders. We are committed to actualising stakeholder value and interest on a long-term sustainable basis." },
  { title: "Client Focus", text: "We are always client focused and will deliver what the client needs in terms of value, quality and satisfaction." },
  { title: "Respect for People", text: "We uphold humanness and human dignity as our core value, simultaneously respecting and valuing people while remaining uncompromised with result orientation and setting high performance standards for ourselves as individuals and teams. We believe a strong team is founded on a variety of perspectives, and we encourage individuals to dream, value differences, create and experiment in pursuit of opportunities and achieve leadership through teamwork." },
  { title: "Excellence", text: "We are resolved to do what is right, do it well and win. We trust that we will strive for excellence in whatever we do." },
  { title: "Innovation", text: "We believe that innovation will keep us competitive and relevant in today's fast-paced world. We will constantly adapt to changing market trends, improve products and services, and find new ways to resolve problems — fostering a culture of creativity that encourages thinking outside the box." },
  { title: "Nation Orientation", text: "We are aware of our responsibility to generate economic value for the Nation. In pursuit of our goals, we will make no compromise in complying with applicable laws and regulations at all levels." },
  { title: "Inclusion, Equality and Diversity", text: "By prioritising inclusion, equality and diversity as values, we will foster a culture of respect, understanding and collaboration among people from diverse backgrounds to build a more successful and harmonious workplace." },
  { title: "Transparency", text: "We will maintain a culture of transparency as a core organisational value because we believe it is essential for building trust, fostering open communication and promoting accountability. Prioritising transparency creates a culture of honesty and integrity where information is shared openly and decisions are made with clarity and fairness." },
];

export const aims = [
  "To promote social, economic and environmental sustainability in focused thematic areas through participation of stakeholders and communities to encourage sustainable and equitable use of natural resources.",
  "To bring together and build capacities of stakeholders while facilitating interaction and cooperation between national and international organizations, agencies and development communities.",
  "To transform lives of individuals, communities and the world through designing and implementing workable strategies to end poverty and inequality, protect the planet, and ensure that all people enjoy health, justice and prosperity — while ensuring no poor or underprivileged person is left behind.",
  "To build capacities of stakeholders and strengthen their processes to reduce poverty, to improve livelihoods and economies and to improve the standard of living of less privileged people.",
  "To create an environment that is pro-poor by reducing poverty, pro-development towards achieving sustainable growth, while promoting equality, equity and inclusivity for enhanced socio-economic status of societies.",
];

export const mainObjectives = [
  "Promote socio-economic development and alleviate poverty by addressing water, sanitation, waste, hunger and food insecurity and the environment crisis, and by promoting adequate and proper management of nature and natural resources as the primary focus of our development endeavour — in alignment with the development goals, strategies and priorities of the national government and with sustainable development goal agendas.",
  "Engage with development in the context and through the medium of human cultures; undertake planning, design, implementation, monitoring and evaluation of corporate social responsibility initiatives; and create partnerships with corporations, foundations, NGOs and public sector organisations to meet our objectives under the Corporate Social Responsibility law applicable in the country.",
  "Promote a society where people of diverse cultures are able to define their own development paradigm and fulfil their economic, social, cultural and spiritual aspirations.",
  "Carry in our objects the promotion of commerce, art, science, sports, education, research, social welfare, religion, charity, protection of the environment or any such other object.",
  "Apply our profits, if any, or other income in promoting our objects, and prohibit the payment of any dividend to our members.",
  "Provide and promote social welfare in every way including education, agriculture, health, environment, culture, human rights and crime control; create general awareness about social, environmental, developmental, educational and human rights issues by organising various programmes for the betterment of people's livelihoods; contribute to environment management through activities in social forestry, wildlife protection and bio-diversity management; and create awareness amongst the general public about their rights.",
];

export const ancillaryObjectives = [
  "Undertake planning, assessments, execution/implementation and evaluation of projects, programs and policies across themes and sectors like poverty alleviation, energy, environment and natural resource management, human development, gender, diversity and social inclusion, social welfare, protection and development, economic policy and development, urban and rural development, agriculture and food security, climate change and disaster risk management including relief and restoration, human rights, culture, education, health and digital technology, water, sanitation, waste, hunger and nutrition, community development, livelihood, skills development, promotion and strengthening of micro, small and medium enterprises, and promotion of peace and sustainable development goals.",
  "Undertake research, studies and assessments, including impact evaluation and policy analysis, of development initiatives of governments and development sector partners.",
  "Promote the performing arts and artistic expression as a medium of communication through which we understand our experiences, ideas, feelings and insights and build identity — that essential component of humanity and community which allows us to learn and develop as people.",
  "Promote and strengthen social, economic and environmental development, sustainability and corporate social responsibility initiatives, and contribute in a collaborative manner wherever applicable and possible.",
  "Strengthen Local Self-Government to become inclusive, participatory, just and efficient institutions of the people which address food and livelihood security, health, education and other primary entitlements.",
  "Advocate sustainable and decentralised natural resource management as the principal means of addressing hunger and food and livelihood insecurity.",
  "Collaborate and promote inclusive development objectives through policy, research, projects and program management with organisations, institutions and agencies involved in promoting the same.",
  "Support communities, and in particular the marginalised of the rural milieu, to build on their capacity to pursue sustainable development and strengthen their own cultural identities and values through renewal and innovation.",
  "Advocate necessary changes in society and governance so that powers, responsibilities and functions move from the community outwards only on the basis of necessity through concentric tiers of governance — from the local through the state to the national and global.",
  "Foster the use of local and indigenous knowledge as a key resource for empowering communities to combat marginalisation, poverty and impoverishment — knowledge that includes know-how, resource use practices and representations embodying sophisticated sets of understandings, interpretations and meanings that are part of a cultural complex encompassing language, naming and classification systems, ritual, spirituality and worldview, to harmonise development with culture and spirituality.",
  "Advocate a more holistic approach to development which does not divorce the material from the non-material and recognises the unity of all belief systems and the need to relate development to the whole of human existence.",
  "Pursue any other objective charitable in nature and of public utility as may be defined or interpreted as 'charitable' by the Income Tax Act, 1961 for the time being in force.",
];

export const enablingPowers = [
  "Collaborate with academic, research, government and non-governmental institutions, community-based organisations (CBOs), civil society organisations (CSOs), corporate foundations and consultancy agencies, both national and international, in the implementation of projects and programs, undertaking studies and action research, and sharing of information.",
  "Serve as a resource centre for collecting, storing, collating and disseminating suitable communication materials and information from different sources to complement the main objectives of the company.",
  "Incubate ideas and opportunities for leveraging information technology for economic, social and cultural growth.",
  "Undertake, conduct, organise, support, encourage and participate in seminars, workshops, conferences, congresses, conventions, councils, training, lecture series and group discussions to generate public awareness and to increase awareness among policy makers.",
  "Develop, print and publish papers, reports, newsletters, books, booklets and leaflets, and produce audio/video materials and other multi-media presentations to complement the main objectives of the company.",
  "Promote, sponsor, support and encourage publication of books, literature and journals, production of performing arts and multi-media presentations, and the organising of lectures, seminars and workshops likely to advance the company's objects — and carry out development programs and interventions in gender equality, education, agriculture and natural resources, poverty alleviation, health and nutrition, slum development, environment, renewable energy, water resources, and income and livelihood creation.",
  "Fix and demand fees and other charges for products sold and services rendered by the company.",
  "Establish and support professorships, fellowships and lectureships, scholarships, chairs and prizes and loans at any institution dealing with the objectives of the company.",
  "Undertake and prosecute practical research assignments in any branch of an alternative development paradigm, independently and/or in alliance with civil society organisations and governmental or non-governmental institutions in India and abroad.",
  "Act as a consultant, counsellor, facilitator and/or provider of information to any institution, organisation or individual on food and livelihood security, local self-governance and strategic communication.",
  "Provide vocational and educational guidance and counselling, and establish or support vocational guidance bureaux, whether virtual or real.",
  "Organise exchange programs for representatives, functionaries, staff and people involved in local self-governance initiatives, and provide training of work in India or abroad.",
  "Advocate engagement of the media to step up coverage on sustainable rural development and local self-governance issues.",
  "Make donations, grant endowments or otherwise assist any person, organisation, public charitable institution, company, society, trust, foundation, academic or cultural institution having objects similar to those of the company.",
  "Establish branches and offices in different parts of India and abroad.",
  "Take on lease, on leave and licence, or otherwise acquire or obtain possession of property as may be deemed fit in furtherance of the company's objects.",
  "Furnish and maintain offices, premises, centres, institutions and other establishments for the furtherance of the company's objects.",
  "Borrow or raise money on such terms and security as may be thought fit, and accept donations, contributions, subscriptions, grants and property of any kind.",
  "Apply the whole or any part of the income of the company to any one or more of its objects, as the Board of Directors may in their discretion deem fit.",
  "Retain or employ skilled professionals or technical advisors in connection with the objectives of the company and pay professional fees or remuneration as may be thought fit.",
];

export const strategies = [
  { title: "Strategic Management Practices", text: "We will continue to practise a strategic management process to formulate and implement long-term plans and actions to achieve the organisation's mission and goals effectively, by analysing the internal and external environment, setting objectives, identifying priorities and making informed decisions to maximise impact." },
  { title: "Purpose Driven Leadership", text: "We will articulate a compelling vision, unite teams with a shared sense of purpose, and navigate challenges with resilience — enhancing our performance by integrating innovative strategies that align with our mission and target the specific needs of our beneficiaries." },
  { title: "Foster Strong Community Partnerships", text: "We believe collaboration is key to achieving lasting impact, and we will continue to leverage community partnerships to amplify our efforts. Establishing strong relationships with local institutions, businesses, government agencies and other non-profits leads to shared resources, increased reach and enhanced program effectiveness." },
  { title: "Harness the Power of Technology", text: "Technology is essential for our long-term growth and success, allowing us to scale our impact and engage with supporters in ways we couldn't have imagined before — from social media outreach to data analytics for impact assessment, working smarter and more efficiently." },
  { title: "Invest in Continuous Learning", text: "To thrive in a rapidly evolving landscape we will prioritise continuous learning and adaptability, valuing a growth mindset that sees challenges as opportunities to learn and improve, and encouraging a culture of learning and professional development to foster innovation." },
  { title: "Create Diverse Revenue Streams", text: "Diversifying revenue streams is a crucial aspect of long-term sustainability. We will endeavour to create a diverse program, project and service portfolio to maintain a varied funding base, providing a stable foundation for our mission and allowing us to remain agile in challenging times." },
];

export const policyFramework = "Our policy framework plays a crucial role in guiding the operations and impact of our activities. It provides a structured approach for decision-making, setting priorities, and defining the organisation's goals and objectives. A well-defined policy framework helps ensure consistency in our actions, promotes transparency, and enhances accountability to stakeholders. It also serves as a tool for advocacy, enabling us to influence government policies, mobilise resources and drive systemic change. By establishing clear policies on governance, program implementation and stakeholder engagement, we effectively navigate complex challenges, uphold our values, and achieve our mission of creating positive social and environmental impact.";

export const organisationIntro = "United Nature is a non-profit entity that was formally incorporated on 17 March 2021 under Section 8 of the Companies Act, 2013 with the Ministry of Corporate Affairs of the Government of India. The organisational components of United Nature include an Advisory Board, Board of Governors, Board of Directors, Management Leadership and Executive Team, Experts and Staff, volunteers and partners — which encompass shareholders as well.";

export const organisationParts = [
  { to: "/about/global-advisory-board", title: "Global Advisory Board", text: "Strategic guidance, expertise and support from accomplished professionals with national and international experience." },
  { to: "/about/board-of-governors", title: "Board of Governors", text: "The ultimate policymakers and decision makers who govern the foundation." },
  { to: "/about/board-of-directors", title: "Board of Directors", text: "The main governing body that approves policies, budgets and operations." },
  { to: "/about/management", title: "Management", text: "Management leadership, executive team, experts and staff, volunteers and partners." },
];

export const advisoryBoard = [
  {
    name: "Nico van Oudenhoven",
    role: "Principal Advisor — Training and Advocacy",
    photo: nicoPhoto.url,
    bio: "A former child psychologist, Nico worked in clinical and academic settings and with a range of international development agencies. He is co-founder and now Senior Associate of International Child Development Initiatives (ICDI.nl), an internationally working NGO based in the Netherlands. With colleagues from the Global South he works at the intersection of research, practice, policy, training and advocacy, aiming to improve the life chances of children, young people and their families who are exposed to toxic environments.",
  },
  {
    name: "Dr. Avinash Kumar",
    role: "Principal Advisor — Programme and Policy Research",
    photo: avinashPhoto.url,
    bio: "Dr. Avinash Kumar holds a Ph.D. from Jawaharlal Nehru University, New Delhi, and was a Charles Wallace Postdoctoral Fellow at the School of Oriental and African Studies (SOAS), London University. He has been a Distinguished Fellow at the Centre for Equity Studies, Delhi. Among his many roles over twenty years, he has taught at Mahatma Gandhi International Hindi University, was research editor at the SARAI Programme of the Centre for the Study of Developing Societies (CSDS), and worked with Oxfam GB, Oxfam India and WaterAid India, and as Executive Director at Amnesty International India. A founder member of civil society networks such as Wada Na Todo Abhiyan and the Right to Education Forum in India, his interests are governance and accountability and access to basic rights such as water, health and education from a rights-based perspective.",
  },
  {
    name: "Dr. Madhuri Gupta",
    role: "Principal Advisor — Institutional Partnerships and Sustainability",
    photo: madhuriPhoto.url,
    bio: "Dr. Madhuri Gupta holds a Ph.D. in Agricultural Biotechnology, complemented by M.Tech and B.Tech degrees in Biotechnology. She collaborates closely with agri-tech start-ups, Farmer Producer Organisations (FPOs) and Self-Help Groups (SHGs) to enhance product development and establish effective marketing linkages. She is Chief Executive Officer of Meerut Udyami Foundation, an agri-business incubator under Meerut Institute of Technology, and co-founder and former Chief Executive Officer of Reverential Education Academy (REA) in Meerut. She has also headed women entrepreneur nurturing and networking at the MIET Incubation Forum. She was recognised as an 'Excellent Entrepreneur' in 2023 by Swadeshi Jagran Manch and received the 'Uttar Pradesh Education Leadership Award' in 2022.",
  },
  {
    name: "Jayashree Jayaraman",
    role: "Principal Advisor — Social Development, CSR & Sustainability",
    photo: jayashreePhoto.url,
    bio: "Jayashree Jayaraman holds an M.Phil, M.A. and B.A. from Delhi University and brings over 30 years of experience, including 25 years in the development sector and six years in research, development and teaching at Delhi University. She is currently Deputy Director at The Lepra India Trust and has advised foundations and charities including JoyWing Foundation and People Against Rape in India (PARI). Her leadership roles include Chief Operating Officer at Partners in Prosperity, Executive Director at Nurturinglife Foundation, and Associate Director – Programs and Resource Mobilisation at United Way (India). Her strengths lie in grant management, public–private partnerships and corporate social responsibility.",
  },
  {
    name: "Dr. Ashutosh Srivastava",
    role: "Principal Advisor — Psychosocial Behaviour Change and Career",
    photo: ashutoshPhoto.url,
    bio: "Dr. Ashutosh Srivastava is (Honorary) Director of the Psyuni Institute of Psychology & Allied Sciences in Lucknow and President of the Bharatiya Counselling Psychology Association of India. He is also a Board Member of the International ReAttach Therapy Foundation in the Netherlands. He holds a Ph.D. in Psychology from the University of Lucknow, an M.Phil in Clinical Psychology from Gautam Buddha University and an M.A. in Psychology from the University of Lucknow, and is a certified therapist and trainer of The ReAttach Therapy Institute, Netherlands. With over 18 years of experience in psychotherapy, clinical and psychological counselling, social behaviour change and communication (SBCC), he has trained over 10,000 professionals and developed training programs for organisations such as NCAO, NIPCCD and UNICEF.",
  },
  {
    name: "Dr. Ruchi Saxena",
    role: "Principal Advisor — Emerging Technologies and Development",
    photo: ruchiPhoto.url,
    bio: "Dr. Ruchi Saxena is Founder-Director of Caerobotics and supports the adoption of emerging technologies for public health and development. She has laid the foundation for several collaborative ecosystems including the International Society for Quality and Safety in Healthcare, the Global Alliance on Drones in Development, India Flying Labs, the UAV Rapid Response Task Force, Project WINGS, Drones for Daughters, Project Caerodrome and the upcoming Global Alliance on Health Research and Innovations. She has been a consultant and coach for healthcare organisations on quality, safety, process and system design, continual improvement and technology adoption, and is devoted to making solutions that promote health and safety equitable, accessible and available for all.",
  },
];

export const boardOfGovernors = "The Directors, Promoters and shareholders are represented by a Board of Governors, who are the ultimate policymakers, decision makers and Governors at United Nature. Generally, directors meet once a year at the Annual Meeting of the Boards of Directors and Governors of United Nature.";

export const boardOfDirectors = "The Board of Directors (BoD) is the main governing body of the organisation. The Directors supervise the organisation's financial statements, approve its administrative budget, and review and approve all policy documents and all loan, equity and technical assistance operations. Directors are in charge of approving policies and plans and ensuring they are carried out. The Board may also appoint an executive director or independent director to supervise the organisation's operations. The Board of Directors includes both Directors and Promoters of the organisation.";

export const managementSections = [
  { title: "Management Leadership", text: "United Nature exercises and maintains a wide spectrum of decentralised as well as flat management systems to carry out operations and administration. The President heads a management leadership comprising a Managing Director General and thematic Vice-Presidents. The team supervises the work of United Nature's operational, administrative and knowledge departments, and the management leadership team is accountable to the entire management and results." },
  { title: "Executive Team", text: "The Executive Director heads the executive team comprising a Chief Executive Officer, Chief Operation Officer, Chief Financial Officer, Managing Directors and thematic associate directors. The team ensures that policies, plans and execution comply with the policies and procedures of the organisation and are in alignment with the policies of the government and partners, and executes United Nature's operational, administrative and knowledge departments." },
  { title: "Experts and Staff", text: "Heads of various departments and themes lead the team of experts and staff. It comprises departmental, program and policy heads, senior managers, managers, associate managers, consultants, senior consultants, associates, associate consultants, trainers, analysts, accountants and human resource management personnel." },
  { title: "Volunteers, Interns and Apprenticeships", text: "United Nature encourages volunteerism and builds a pool of volunteers with diverse socio-economic backgrounds. Although volunteers are not like paid staff, United Nature recognises their contribution to the organisation through appreciation and monetary tokens to encourage them." },
  { title: "Partners and Stakeholders", text: "United Nature considers partners and stakeholders an integral part of the organisation and foundation pillars for all growth and development. Our partners and stakeholders may include, but are not limited to, business partners, external consultants and advising organisations, governments and public sector organisations and institutions, international organisations, private sector and foundations, INGOs and NGOs, community based institutions and communities." },
];

export const approachIntro = "United Nature has adopted a 'Life Cycle Approach' across all its thematic interventions to serve the actual purpose and contribute towards impact. Individuals, families and community based organisations are the key target groups for us, as we believe no thematic intervention can be done in isolation without ensuring the upliftment and participation of the community as a whole.";

export const approachPoints = [
  { title: "Community Development", text: "Our Community Development approach deploys integrated approaches — community demand driven, scientific-evidence based, needs-based, problem-solving, participatory, asset-based, power-conflict, welfare and rights-based — embedded with participatory, inclusivity, gender and diversity principles." },
  { title: "Strategic and Systemic Planning", text: "We deploy strategic planning processes adopting models such as the basic, issue-based, alignment, scenario, self-organization, real-time and inspirational models, and frameworks including the Logical Framework, SWOT analysis, OKRs, Balanced Score Card, Porter's Five Forces, VARIO, Theory of Constraints and PESTLE analysis." },
  { title: "Direct Field-Level Implementation", text: "We work at the grassroots level, collaborating directly with communities through skilled, experienced and highly qualified subject matter experts on the ground, supporting community based institutions and individuals so they take the lead in their own development." },
  { title: "Life Cycle & Result Based Management", text: "We work on the most relevant issues of the most marginalised communities in a results oriented manner to strengthen community based organisations and communities, bringing socio-economic empowerment and creating sustainable change." },
  { title: "Sustainability Focus", text: "Sustainability is key to our purpose of bringing people and resources together to build a better world, addressing the economic, social and environmental determinants such as food, climate, nature, circularity and social sustainability." },
  { title: "National Development", text: "We align our strategies with government policies and use community–public–private partnerships to enhance the standard of living and economic well-being of the nation, based on a human-centric development model of respect, diversity, care for the future and sustainable development." },
  { title: "Sustainable Development Goals", text: "Our approach and objectives are aligned with the seventeen Sustainable Development Goals (SDGs) established by the United Nations, covering poverty eradication, quality education, gender equality, clean water and sanitation, affordable and clean energy, sustainable cities and communities, climate action, and life below water and on land." },
];
