import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Phone, MapPin, CheckCircle2 } from "lucide-react";
import hero from "@/assets/planting.jpg";
import { PageHero, meta } from "@/components/site";

export const Route = createFileRoute("/contact")({
  head: () => meta("Contact Us — United Nature Sustainability Foundation", "Partner, volunteer or reach out to United Nature Sustainability Foundation."),
  component: Contact,
});

const field = "w-full rounded-xl border bg-background px-4 py-3 outline-none focus:ring-2 focus:ring-ring";

function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <>
      <PageHero eyebrow="Contact us" title="Let's grow something together." text="Whether you want to partner, volunteer or donate — we'd love to hear from you." image={hero} />
      <section className="mx-auto grid max-w-7xl gap-12 px-5 py-24 md:grid-cols-5">
        <div className="space-y-6 md:col-span-2">
          {[
            { i: Mail, t: "Email", d: "nasirsahar@gmail.com" },
            { i: Phone, t: "Phone", d: "+91 80760 18169 (Nasiruddin Nasir, Managing Director)" },
            { i: MapPin, t: "Registered Office", d: "House No. 306, Kh No. 27/9, 2nd Floor, Blk-A, Meer Vihar, Landmark: Mangal Bazar, Delhi – 110081, India" },
          ].map((c) => (
            <div key={c.t} className="flex gap-4 rounded-2xl bg-secondary/60 p-6">
              <c.i className="h-6 w-6 text-primary" />
              <div><p className="font-semibold">{c.t}</p><p className="text-muted-foreground">{c.d}</p></div>
            </div>
          ))}
        </div>
        <div className="rounded-[2rem] border bg-card p-8 shadow-soft md:col-span-3">
          {sent ? (
            <div className="py-16 text-center">
              <CheckCircle2 className="mx-auto h-12 w-12 text-primary" />
              <h2 className="mt-4 text-3xl">Thank you!</h2>
              <p className="mt-2 text-muted-foreground">We'll get back to you soon.</p>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="grid gap-4 sm:grid-cols-2">
              <input required placeholder="Full name" className={field} />
              <input required type="email" placeholder="Email" className={field} />
              <select className={`${field} sm:col-span-2`} defaultValue="Partnership">
                <option>Partnership</option><option>Volunteer</option><option>Donation</option><option>General enquiry</option>
              </select>
              <textarea required rows={5} placeholder="Your message" className={`${field} sm:col-span-2`} />
              <button className="btn-primary justify-center sm:col-span-2">Send message</button>
            </form>
          )}
        </div>
      </section>
    </>
  );
}
