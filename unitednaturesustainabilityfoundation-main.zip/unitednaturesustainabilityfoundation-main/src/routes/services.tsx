import { createFileRoute } from "@tanstack/react-router";
import hero from "@/assets/farm.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { services, fpoServices, whyChooseUs } from "@/lib/content";
import { CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/services")({
  head: () => meta("Services — United Nature Sustainability Foundation", "Consulting, project management, research & impact assessment, capacity building, CSR support and FPO consulting services."),
  component: Services,
});

function Services() {
  return (
    <>
      <PageHero eyebrow="Services" title="Expertise that turns intent into impact." text="We partner with corporates, governments and communities to design and deliver sustainability programs." image={hero} />
      <section className="mx-auto max-w-7xl px-5 py-24">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <div key={s.title} className="rounded-2xl border bg-card p-8 transition hover:-translate-y-1 hover:shadow-soft">
              <div className="flex items-center justify-between">
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-secondary text-primary"><s.icon className="h-7 w-7" /></span>
                <span className="font-display text-3xl text-border">0{i + 1}</span>
              </div>
              <h3 className="mt-6 text-2xl">{s.title}</h3>
              <p className="mt-3 text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="bg-secondary/50 py-24">
        <div className="mx-auto max-w-7xl px-5">
          <p className="eyebrow">Consulting for Stronger FPOs</p>
          <h2 className="mt-3 text-4xl">Our Consulting Services for Farmer Producer Organizations</h2>
          <p className="mt-4 max-w-3xl text-lg text-muted-foreground">We provide end-to-end consulting and advisory services to FPOs to help them form, comply, grow and become market-driven, financially sustainable and future-ready.</p>
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {fpoServices.map((s) => (
              <div key={s.title} className="flex gap-5 rounded-2xl border bg-card p-7">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-secondary text-primary"><s.icon className="h-6 w-6" /></span>
                <div>
                  <h3 className="text-xl">{s.title}</h3>
                  <ul className="mt-3 list-disc space-y-1 pl-5 text-muted-foreground">{s.points.map((p) => <li key={p}>{p}</li>)}</ul>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-14 grid gap-8 md:grid-cols-2">
            <div>
              <h3 className="text-2xl">Why choose us?</h3>
              <ul className="mt-5 space-y-3">{whyChooseUs.map((w) => <li key={w} className="flex gap-3"><CheckCircle2 className="h-5 w-5 shrink-0 text-primary" />{w}</li>)}</ul>
            </div>
            <div className="rounded-2xl bg-primary p-8 text-primary-foreground">
              <h3 className="text-2xl">Our focus</h3>
              <p className="mt-3 opacity-90">Building independent, well-governed and market-ready FPOs for long-term prosperity.</p>
              <p className="mt-6 font-display text-xl italic">"When FPOs grow, farmers grow, communities grow and the nation grows."</p>
            </div>
          </div>
        </div>
      </section>
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-5">
          <p className="eyebrow">How we work</p>
          <h2 className="mt-3 text-4xl">Our approach</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-4">
            {["Listen & assess", "Co-design", "Implement", "Measure & report"].map((s, i) => (
              <div key={s}>
                <div className="font-display text-5xl text-primary">{i + 1}</div>
                <h3 className="mt-3 text-xl">{s}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>
      <CTA />
    </>
  );
}
