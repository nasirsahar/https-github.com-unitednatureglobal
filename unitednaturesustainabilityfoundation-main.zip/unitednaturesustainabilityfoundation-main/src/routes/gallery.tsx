import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { X } from "lucide-react";
import hero from "@/assets/hero.jpg";
import planting from "@/assets/planting.jpg";
import farm from "@/assets/farm.jpg";
import education from "@/assets/education.jpg";
import { PageHero, meta } from "@/components/site";

export const Route = createFileRoute("/gallery")({
  head: () => meta("Gallery — United Nature Sustainability Foundation", "Photos from our plantation drives, farms, classrooms and restored landscapes."),
  component: Gallery,
});

const photos = [
  { src: planting, t: "Community plantation drive", c: "Forests" },
  { src: hero, t: "Protected river forest", c: "Biodiversity" },
  { src: education, t: "Outdoor eco-classroom", c: "Education" },
  { src: farm, t: "Solar-powered farming", c: "Livelihoods" },
  { src: education, t: "Youth eco-club", c: "Education" },
  { src: planting, t: "Sapling care", c: "Forests" },
];

function Gallery() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <>
      <PageHero eyebrow="Gallery" title="Moments from the field." text="A glimpse into our work with communities and nature." image={education} />
      <section className="mx-auto max-w-7xl px-5 py-24">
        <div className="columns-1 gap-5 sm:columns-2 lg:columns-3">
          {photos.map((p, i) => (
            <button key={i} onClick={() => setOpen(i)} className="group relative mb-5 block w-full overflow-hidden rounded-2xl text-left">
              <img src={p.src} alt={p.t} loading="lazy" className={`w-full object-cover transition duration-700 group-hover:scale-105 ${i % 3 === 1 ? "h-96" : "h-72"}`} />
              <div className="hero-overlay absolute inset-0 opacity-0 transition group-hover:opacity-100" />
              <div className="absolute bottom-4 left-4 text-deep-foreground opacity-0 transition group-hover:opacity-100">
                <p className="text-xs uppercase tracking-widest text-bright">{p.c}</p>
                <p className="font-display text-xl">{p.t}</p>
              </div>
            </button>
          ))}
        </div>
      </section>
      {open !== null && (
        <div className="fixed inset-0 z-[60] grid place-items-center bg-deep/95 p-5" onClick={() => setOpen(null)}>
          <button className="absolute right-5 top-5 text-deep-foreground" aria-label="Close"><X className="h-8 w-8" /></button>
          <img src={photos[open]?.src} alt={photos[open]?.t} className="max-h-[85vh] rounded-2xl" />
        </div>
      )}
    </>
  );
}
