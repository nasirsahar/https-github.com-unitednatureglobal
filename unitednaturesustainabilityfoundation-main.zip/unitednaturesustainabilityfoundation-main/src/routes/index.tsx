import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import hero from "@/assets/hero.jpg";
import planting from "@/assets/planting.jpg";
import farm from "@/assets/farm.jpg";
import education from "@/assets/education.jpg";
import { CTA, meta } from "@/components/site";
import { thematicAreas } from "@/lib/content";

export const Route = createFileRoute("/")({
  head: () => meta("United Nature Sustainability Foundation (UNSF) — Official Website", "United Nature Sustainability Foundation India: not-for-profit for sustainable development, FPO consulting, CSR, research and capacity building. United We Prevail."),
  component: Index,
});

const stats = [
  ["250K+", "Trees planted"],
  ["120+", "Villages reached"],
  ["40K+", "Lives impacted"],
  ["60+", "Partners"],
];

function Index() {
  return (
    <>
      <section className="relative isolate min-h-[88vh] overflow-hidden">
        <img src={hero} alt="Forest and river at sunrise" width={1920} height={1088} className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="hero-overlay absolute inset-0 -z-10" />
        <div className="mx-auto flex min-h-[88vh] max-w-7xl flex-col justify-end px-5 pb-20 text-deep-foreground">
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-bright">United Nature Sustainability Foundation</p>
          <h1 className="mt-5 max-w-4xl text-5xl leading-[1.05] md:text-7xl">
            Healing the planet, <em className="text-bright">one community</em> at a time.
          </h1>
          <p className="mt-6 max-w-xl text-lg opacity-85">We restore ecosystems, protect water and empower people to live in harmony with nature.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/contact" className="btn-bright">Join the movement <ArrowRight className="h-4 w-4" /></Link>
            <Link to="/about" className="btn-ghost-light">Who we are</Link>
          </div>
        </div>
      </section>

      <section className="border-b bg-card">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-5 py-12 md:grid-cols-4">
          {stats.map(([n, l]) => (
            <div key={l}>
              <div className="font-display text-4xl text-primary md:text-5xl">{n}</div>
              <div className="mt-1 text-sm text-muted-foreground">{l}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-24 md:grid-cols-2">
        <img src={planting} alt="Volunteers planting trees" loading="lazy" width={1280} height={960} className="rounded-[2rem] shadow-soft" />
        <div>
          <p className="eyebrow">Our mission</p>
          <h2 className="mt-3 text-4xl md:text-5xl">Nature-positive change, led by communities.</h2>
          <p className="mt-5 text-lg text-muted-foreground">We believe lasting sustainability grows from the ground up. Our programs combine science, local wisdom and partnerships to deliver measurable impact for people and the planet.</p>
          <Link to="/about" className="btn-primary mt-8">Learn about us <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </section>

      <section className="bg-secondary/50 py-24">
        <div className="mx-auto max-w-7xl px-5">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Thematic areas</p>
              <h2 className="mt-3 text-4xl md:text-5xl">Where we focus</h2>
            </div>
            <Link to="/thematic-areas" className="font-semibold text-primary">View all →</Link>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {thematicAreas.slice(0, 4).map((a) => (
              <div key={a.title} className="rounded-2xl bg-card p-7 transition hover:-translate-y-1 hover:shadow-soft">
                <a.icon className="h-8 w-8 text-primary" />
                <h3 className="mt-5 text-xl">{a.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{a.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-24">
        <p className="eyebrow">Stories from the field</p>
        <h2 className="mt-3 text-4xl md:text-5xl">Impact you can see</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {[{ img: farm, t: "Solar-powered farms for women farmers" }, { img: education, t: "Green classrooms for the next generation" }].map((s) => (
            <div key={s.t} className="group relative overflow-hidden rounded-[2rem]">
              <img src={s.img} alt={s.t} loading="lazy" width={1280} height={960} className="h-96 w-full object-cover transition duration-700 group-hover:scale-105" />
              <div className="hero-overlay absolute inset-0" />
              <h3 className="absolute bottom-6 left-6 right-6 text-2xl text-deep-foreground">{s.t}</h3>
            </div>
          ))}
        </div>
      </section>

      <CTA />
    </>
  );
}
