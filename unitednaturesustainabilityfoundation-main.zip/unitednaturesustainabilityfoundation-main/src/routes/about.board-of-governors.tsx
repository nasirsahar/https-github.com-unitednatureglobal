import { createFileRoute, Link } from "@tanstack/react-router";
import planting from "@/assets/planting.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { boardOfGovernors } from "@/lib/content";

export const Route = createFileRoute("/about/board-of-governors")({
  head: () => meta("Board of Governors — United Nature Sustainability Foundation", "The Board of Governors represents the Directors, Promoters and shareholders and acts as the ultimate policymaking and decision-making body of United Nature."),
  component: BoardOfGovernors,
});

function BoardOfGovernors() {
  return (
    <>
      <PageHero
        compact
        eyebrow="Who we are · Organisation"
        title="Board of Governors"
        text="The ultimate policymakers, decision makers and Governors at United Nature."
        image={planting}
      />

      <section className="mx-auto max-w-5xl px-5 py-20">
        <p className="text-lg leading-relaxed text-muted-foreground">{boardOfGovernors}</p>
        <div className="mt-12 grid gap-5 sm:grid-cols-2">
          <div className="rounded-2xl border bg-card p-8">
            <h3 className="text-xl">How the Board governs</h3>
            <p className="mt-3 text-muted-foreground">
              Governors meet at the Annual Meeting of the Boards of Directors and Governors to set direction, review performance
              and safeguard the Foundation's not-for-profit purpose under Section 8 of the Companies Act, 2013.
            </p>
          </div>
          <div className="rounded-2xl bg-secondary/60 p-8">
            <h3 className="text-xl">Continue exploring</h3>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li><Link to="/about/board-of-directors" className="font-semibold text-primary">Board of Directors →</Link></li>
              <li><Link to="/about/management" className="font-semibold text-primary">Management →</Link></li>
              <li><Link to="/about/global-advisory-board" className="font-semibold text-primary">Global Advisory Board →</Link></li>
            </ul>
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}
