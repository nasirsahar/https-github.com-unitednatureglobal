import { createFileRoute } from "@tanstack/react-router";
import { Info } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { registrations, contact } from "@/lib/content";

export const Route = createFileRoute("/legality")({
  head: () => meta("Legality & Registrations — United Nature Sustainability Foundation", "12A, 80G, CSR-1, NGO Darpan, UDYAM MSME, GeM and GuideStar India registrations of United Nature Sustainability Foundation."),
  component: Legality,
});

function Legality() {
  return (
    <>
      <PageHero eyebrow="Legality" title="Registered, recognised and accountable." text="United Nature Sustainability Foundation is recognised under relevant Government of India platforms and regulations." image={hero} />
      <section className="mx-auto max-w-7xl px-5 py-24">
        <p className="eyebrow">Registrations & Platforms</p>
        <h2 className="mt-3 text-4xl">Our legal registrations</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {registrations.map((r) => (
            <div key={r.title} className="rounded-2xl border bg-card p-8 transition hover:-translate-y-1 hover:shadow-soft">
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-secondary text-primary"><r.icon className="h-7 w-7" /></span>
              <h3 className="mt-6 text-2xl">{r.title}</h3>
              <p className="mt-1 text-sm font-semibold text-primary">{r.authority}</p>
              <p className="mt-3 text-muted-foreground">{r.text}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          <div className="rounded-2xl bg-secondary/60 p-8">
            <h3 className="text-xl">Registered Office (MCA)</h3>
            <p className="mt-3 text-muted-foreground">{contact.address}</p>
          </div>
          <div className="flex gap-4 rounded-2xl border p-8">
            <Info className="h-6 w-6 shrink-0 text-primary" />
            <p className="text-muted-foreground">Copies of registration certificates are available on request for partners, donors and government agencies. Please verify registration validity and current details before formal use — write to {contact.email}.</p>
          </div>
        </div>
      </section>
      <CTA />
    </>
  );
}
