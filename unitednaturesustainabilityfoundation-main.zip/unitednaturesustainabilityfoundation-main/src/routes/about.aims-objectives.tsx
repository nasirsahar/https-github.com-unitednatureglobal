import { createFileRoute, Link } from "@tanstack/react-router";
import farm from "@/assets/farm.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { aims, ancillaryObjectives, enablingPowers, mainObjectives } from "@/lib/content";

export const Route = createFileRoute("/about/aims-objectives")({
  head: () => meta("Our Aims and Objectives — United Nature Sustainability Foundation", "The aims, main objects, ancillary objects and enabling provisions of United Nature Sustainability Foundation as set out in its Memorandum of Association."),
  component: AimsObjectives,
});

function AimsObjectives() {
  return (
    <>
      <PageHero
        compact
        eyebrow="Who we are"
        title="Our Aims and Objectives"
        text="Our aims and objectives, as set out in the Memorandum of Association, keep social, economic and environmental sustainability at the centre of everything we do."
        image={farm}
      />

      <section className="mx-auto max-w-7xl px-5 py-20">
        <p className="eyebrow">Our aims</p>
        <h2 className="mt-3 max-w-3xl text-4xl">Five aims that frame our work</h2>
        <ol className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {aims.map((a, i) => (
            <li key={a.slice(0, 24)} className="rounded-2xl border bg-card p-7">
              <span className="font-display text-3xl text-primary">{i + 1}</span>
              <p className="mt-3 text-muted-foreground">{a}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="bg-deep py-20 text-deep-foreground">
        <div className="mx-auto max-w-5xl px-5">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-bright">Our objectives</p>
          <h2 className="mt-3 text-4xl">The main objects of the company</h2>
          <p className="mt-4 max-w-2xl opacity-80">The main objects to be pursued by the company on its incorporation are to:</p>
          <ol className="mt-10 space-y-6">
            {mainObjectives.map((o, i) => (
              <li key={o.slice(0, 24)} className="flex gap-5 rounded-2xl border border-deep-foreground/15 p-7">
                <span className="font-display text-3xl text-bright">{i + 1}</span>
                <p className="opacity-85">{o}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-5 py-20">
        <p className="eyebrow">Ancillary objectives</p>
        <h2 className="mt-3 text-4xl">Objects incidental or ancillary to the main objects</h2>
        <ol className="mt-10 space-y-5">
          {ancillaryObjectives.map((o, i) => (
            <li key={o.slice(0, 24)} className="flex gap-5 rounded-xl bg-secondary/50 p-6">
              <span className="font-display text-2xl text-primary">{i + 1}</span>
              <p className="text-muted-foreground">{o}</p>
            </li>
          ))}
        </ol>

        <details className="mt-10 rounded-2xl border bg-card p-6">
          <summary className="cursor-pointer font-display text-2xl">Further enabling provisions</summary>
          <p className="mt-3 text-sm text-muted-foreground">
            To attain the above objects, the company is empowered, among other things, to:
          </p>
          <ul className="mt-5 space-y-3">
            {enablingPowers.map((p) => (
              <li key={p.slice(0, 24)} className="flex gap-3 text-sm text-muted-foreground">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                <span>{p}</span>
              </li>
            ))}
          </ul>
          <p className="mt-5 text-sm text-muted-foreground">
            The complete list of powers is contained in the Memorandum of Association. A copy is available on request — write to us from the
            <a href="/contact" className="font-semibold text-primary"> Contact page</a>.
          </p>
        </details>
      </section>

      <CTA />
    </>
  );
}
