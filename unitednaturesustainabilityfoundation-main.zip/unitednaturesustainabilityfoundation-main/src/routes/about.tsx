import { Link, Outlet, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  component: AboutLayout,
});

const aboutNav = [
  { to: "/about", label: "About United Nature", exact: true },
  { to: "/about/vision-mission-values", label: "Vision, Mission & Values", exact: false },
  { to: "/about/aims-objectives", label: "Aims & Objectives", exact: false },
  { to: "/about/organisation", label: "Our Organisation", exact: false },
  { to: "/about/global-advisory-board", label: "Global Advisory Board", exact: false },
  { to: "/about/board-of-governors", label: "Board of Governors", exact: false },
  { to: "/about/board-of-directors", label: "Board of Directors", exact: false },
  { to: "/about/management", label: "Management", exact: false },
  { to: "/about/strategies-policies", label: "Strategies & Policies", exact: false },
  { to: "/contact", label: "Contact Us", exact: false },
] as const;

const idle = "whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium text-muted-foreground transition hover:bg-muted hover:text-foreground";
const active = "whitespace-nowrap rounded-full px-4 py-2 text-sm font-semibold bg-primary text-primary-foreground";

function AboutLayout() {
  return (
    <>
      <div className="border-b bg-card">
        <div className="mx-auto max-w-7xl px-5">
          <nav aria-label="About United Nature" className="flex gap-1 overflow-x-auto py-3">
            {aboutNav.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                className={idle}
                activeProps={{ className: active }}
                activeOptions={{ exact: item.exact }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
      <Outlet />
    </>
  );
}
