import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { aboutIntro, aboutProfile, contact, inspiration, photos, registrationFacts } from "@/lib/content";

export const Route = createFileRoute("/about/")({
  head: () => meta("About United Nature — United Nature Sustainability Foundation", "Who we are: a Section 8 not-for-profit company incorporated on 17 March 2021 with the Ministry of Corporate Affairs, working across India on sustainability, CSR, research and capacity building."),
  component: AboutUnitedNature,
});

function AboutUnitedNature() {
  return (
    <>
      <PageHero
        eyebrow="Who we are · About us"
        title="About United Nature"
        text={aboutIntro.lead}
        image={hero}
      />

      <section className="mx-auto max-w-7xl px-5 py-20">
        <blockquote className="mx-auto max-w-4xl border-l-4 border-primary pl-6 font-display text-2xl leading-snug text-foreground md:text-3xl">
          “{aboutIntro.commitment}”
        </blockquote>
        <div className="mt-14 grid gap-8 md:grid-cols-2">
          <div className="rounded-2xl border bg-card p-8">
            <p className="eyebrow">Incorporation</p>
            <p className="mt-4 text-muted-foreground">{aboutIntro.incorporation}</p>
          </div>
          <div className="rounded-2xl bg-secondary/60 p-8">
            <p className="eyebrow">Approvals & platforms</p>
            <p className="mt-4 text-muted-foreground">{aboutIntro.approvals}</p>
          </div>
        </div>
      </section>

      <section className="bg-deep py-20 text-deep-foreground">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 md:grid-cols-[280px_1fr]">
          <div>
            <img src={photos.unity} alt="United Nature — many hands forming a circle of unity" width={360} height={360} className="rounded-full bg-deep-foreground/10 p-6" />
            <h2 className="mt-8 text-4xl">Our Profile</h2>
          </div>
          <div className="space-y-6 text-lg opacity-85">
            {aboutProfile.map((p) => <p key={p.slice(0, 32)}>{p}</p>)}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">Registrations at a glance</p>
            <h2 className="mt-3 text-4xl">Our registration details</h2>
          </div>
          <Link to="/legality" className="font-semibold text-primary">Full legality & registrations →</Link>
        </div>
        <dl className="mt-10 grid gap-px overflow-hidden rounded-2xl border bg-border md:grid-cols-2">
          {registrationFacts.map((f) => (
            <div key={f.label} className="bg-card p-5">
              <dt className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{f.label}</dt>
              <dd className="mt-1 font-medium">{f.value}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-20">
        <div className="grid items-start gap-10 rounded-[2rem] border bg-card p-8 md:grid-cols-[220px_1fr] md:p-12">
          <div className="text-center">
            <img src={inspiration.photo} alt={inspiration.name} width={203} height={203} className="mx-auto h-40 w-40 rounded-full object-cover ring-4 ring-secondary" />
            <h3 className="mt-4 text-2xl">{inspiration.name}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{inspiration.caption}</p>
          </div>
          <div>
            <p className="eyebrow">Our inspiration</p>
            <div className="mt-4 space-y-4 text-muted-foreground">
              {inspiration.paragraphs.map((p) => <p key={p.slice(0, 32)}>{p}</p>)}
            </div>
            <p className="mt-6 rounded-xl bg-secondary/60 p-5 text-sm text-secondary-foreground">{inspiration.definition}</p>
          </div>
        </div>
        <p className="mt-8 text-sm text-muted-foreground">
          Registered office: {contact.addressShort} · {contact.phone} · {contact.orgEmail} · {contact.website}
        </p>
      </section>

      <CTA />
    </>
  );
}
