import { createFileRoute, Link } from "@tanstack/react-router";
import farm from "@/assets/farm.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { boardOfDirectors } from "@/lib/content";

export const Route = createFileRoute("/about/board-of-directors")({
  head: () => meta("Board of Directors — United Nature Sustainability Foundation", "The Board of Directors is the main governing body of United Nature, supervising financial statements, approving the administrative budget and all policy documents."),
  component: BoardOfDirectors,
});

function BoardOfDirectors() {
  return (
    <>
      <PageHero
        compact
        eyebrow="Who we are · Organisation"
        title="Board of Directors"
        text="The main governing body of the organisation, comprising both Directors and Promoters."
        image={farm}
      />

      <section className="mx-auto max-w-5xl px-5 py-20">
        <p className="text-lg leading-relaxed text-muted-foreground">{boardOfDirectors}</p>
        <div className="mt-12 grid gap-5 sm:grid-cols-2">
          <div className="rounded-2xl border bg-card p-8">
            <h3 className="text-xl">What the Board approves</h3>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li>· Financial statements and the administrative budget</li>
              <li>· All policy documents</li>
              <li>· Loan, equity and technical assistance operations</li>
              <li>· Policies, plans and their execution</li>
            </ul>
          </div>
          <div className="rounded-2xl bg-secondary/60 p-8">
            <h3 className="text-xl">Continue exploring</h3>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li><Link to="/about/board-of-governors" className="font-semibold text-primary">Board of Governors →</Link></li>
              <li><Link to="/about/management" className="font-semibold text-primary">Management →</Link></li>
              <li><Link to="/about/strategies-policies" className="font-semibold text-primary">Strategies & Policies →</Link></li>
            </ul>
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}
