import { createFileRoute } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { thematicAreas } from "@/lib/content";

export const Route = createFileRoute("/thematic-areas")({
  head: () => meta("Thematic Areas — United Nature Sustainability Foundation", "Forests, water, climate action, renewable energy, agriculture, waste, education and livelihoods."),
  component: Thematic,
});

function Thematic() {
  return (
    <>
      <PageHero eyebrow="Thematic areas" title="Eight pathways to a sustainable future." text="Our programs are aligned with the UN Sustainable Development Goals." image={hero} />
      <section className="mx-auto max-w-7xl px-5 py-24">
        <div className="grid gap-px overflow-hidden rounded-[2rem] border bg-border md:grid-cols-2">
          {thematicAreas.map((a) => (
            <div key={a.title} className="flex gap-6 bg-card p-10">
              <a.icon className="h-10 w-10 shrink-0 text-primary" />
              <div>
                <h3 className="text-2xl">{a.title}</h3>
                <p className="mt-3 text-muted-foreground">{a.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
      <CTA />
    </>
  );
}
