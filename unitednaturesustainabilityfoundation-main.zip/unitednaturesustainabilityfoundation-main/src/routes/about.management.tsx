import { createFileRoute, Link } from "@tanstack/react-router";
import education from "@/assets/education.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { managementSections } from "@/lib/content";

export const Route = createFileRoute("/about/management")({
  head: () => meta("Management — United Nature Sustainability Foundation", "United Nature's management spans management leadership, an executive team, experts and staff, volunteers and interns, and partners and stakeholders."),
  component: Management,
});

function Management() {
  return (
    <>
      <PageHero
        compact
        eyebrow="Who we are · Organisation"
        title="Management"
        text="United Nature exercises and maintains a wide spectrum of decentralised as well as flat management systems to carry out its operations and administration."
        image={education}
      />

      <section className="mx-auto max-w-5xl px-5 py-20">
        <div className="space-y-6">
          {managementSections.map((m, i) => (
            <article key={m.title} className="rounded-2xl border bg-card p-8">
              <div className="flex items-baseline gap-4">
                <span className="font-display text-3xl text-primary">{String(i + 1).padStart(2, "0")}</span>
                <h2 className="text-2xl">{m.title}</h2>
              </div>
              <p className="mt-4 text-muted-foreground">{m.text}</p>
            </article>
          ))}
        </div>

        <div className="mt-12 rounded-2xl bg-secondary/60 p-8">
          <h3 className="text-xl">Work with us</h3>
          <p className="mt-3 text-muted-foreground">
            We welcome volunteers, interns and apprentices from diverse socio-economic backgrounds, and organisations that want to
            partner with us.
          </p>
          <Link to="/contact" className="btn-primary mt-6">Get in touch</Link>
        </div>
      </section>

      <CTA />
    </>
  );
}
