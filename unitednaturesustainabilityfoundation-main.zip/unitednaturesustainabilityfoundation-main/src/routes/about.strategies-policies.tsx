import { createFileRoute } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { photos, policyFramework, strategies } from "@/lib/content";

export const Route = createFileRoute("/about/strategies-policies")({
  head: () => meta("Our Strategies and Policies — United Nature Sustainability Foundation", "How United Nature drives meaningful change: strategic management practices, purpose-driven leadership, community partnerships, technology, continuous learning and diverse revenue streams, guided by a defined policy framework."),
  component: StrategiesPolicies,
});

function StrategiesPolicies() {
  return (
    <>
      <PageHero
        compact
        eyebrow="Who we are"
        title="Our Strategies and Policies"
        text="Strategies give us a road-map for action — prioritising efforts, allocating resources effectively and measuring progress towards a more sustainable future."
        image={hero}
      />

      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="grid items-center gap-12 md:grid-cols-[1fr_320px]">
          <p className="text-lg leading-relaxed text-muted-foreground">
            Our strategies help drive meaningful change and promote sustainable practices by advocating for policy changes,
            conducting research, collaborating with stakeholders and raising awareness. Through a comprehensive strategy framework
            they support poverty reduction, economic growth, social prosperity and sustainability.
          </p>
          <img
            src={photos.framework}
            alt="Sustainability framework linking social, economy, environment and governance with the Sustainable Development Goals"
            width={642}
            height={649}
            loading="lazy"
            className="mx-auto w-full max-w-sm rounded-2xl bg-deep p-4"
          />
        </div>

        <div className="mt-16 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {strategies.map((s, i) => (
            <div key={s.title} className="rounded-2xl border bg-card p-8 transition hover:-translate-y-1 hover:shadow-soft">
              <span className="font-display text-3xl text-primary">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="mt-3 text-xl">{s.title}</h3>
              <p className="mt-3 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-deep py-20 text-deep-foreground">
        <div className="mx-auto max-w-5xl px-5">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-bright">Our policy framework</p>
          <p className="mt-6 text-lg leading-relaxed opacity-90">{policyFramework}</p>
          <p className="mt-8 text-sm opacity-70">
            A copy of the Policy Framework is available on request — please write to us from the Contact page.
          </p>
        </div>
      </section>

      <CTA />
    </>
  );
}
