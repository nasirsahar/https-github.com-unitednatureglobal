import { createFileRoute } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { advisoryBoard } from "@/lib/content";

export const Route = createFileRoute("/about/global-advisory-board")({
  head: () => meta("Global Advisory Board — United Nature Sustainability Foundation", "Meet the Principal Advisors of United Nature: specialists in training and advocacy, programme and policy research, institutional partnerships, social development and CSR, psychosocial behaviour change, and emerging technologies."),
  component: GlobalAdvisoryBoard,
});

function GlobalAdvisoryBoard() {
  return (
    <>
      <PageHero
        compact
        eyebrow="Who we are · Organisation"
        title="Global Advisory Board"
        text="Our Board of Advisors provides strategic guidance, expertise and support. Comprised of highly accomplished professionals with diverse backgrounds, skills and experiences, its members bring national, international and global experience in social development, sustainability, finance, fundraising and program development — contributing their knowledge and networks voluntarily to help the organisation remain accountable, effective and responsive."
        image={hero}
      />

      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="grid gap-8 md:grid-cols-2">
          {advisoryBoard.map((a) => (
            <article key={a.name} className="flex flex-col gap-6 rounded-2xl border bg-card p-8 sm:flex-row">
              <img
                src={a.photo}
                alt={a.name}
                width={200}
                height={200}
                loading="lazy"
                className="h-28 w-28 shrink-0 rounded-full object-cover ring-4 ring-secondary"
              />
              <div>
                <h3 className="text-2xl">{a.name}</h3>
                <p className="mt-1 text-sm font-semibold text-primary">{a.role}</p>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{a.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <CTA />
    </>
  );
}
