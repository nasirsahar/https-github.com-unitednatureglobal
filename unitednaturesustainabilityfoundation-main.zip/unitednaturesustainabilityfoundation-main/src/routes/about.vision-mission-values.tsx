import { createFileRoute } from "@tanstack/react-router";
import planting from "@/assets/planting.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { coreValues, mission, vision } from "@/lib/content";

export const Route = createFileRoute("/about/vision-mission-values")({
  head: () => meta("Our Vision, Mission and Values — United Nature Sustainability Foundation", "The vision, mission and core values that guide United Nature: trusteeship, client focus, respect for people, excellence, innovation, nation orientation, inclusion and transparency."),
  component: VisionMissionValues,
});

function VisionMissionValues() {
  return (
    <>
      <PageHero
        compact
        eyebrow="Who we are"
        title="Our Vision, Mission and Values"
        text="United Nature's Vision and Mission are driven by its Core Values, aimed at developing a stakeholder-focused, high-performance organisation that creates value for all."
        image={planting}
      />

      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="grid gap-8 md:grid-cols-2">
          <div className="rounded-2xl border bg-card p-8">
            <p className="eyebrow">Our vision</p>
            <p className="mt-5 font-display text-2xl leading-snug">{vision}</p>
          </div>
          <div className="rounded-2xl bg-primary p-8 text-primary-foreground">
            <p className="text-xs font-bold uppercase tracking-[0.2em] opacity-80">Our mission</p>
            <div className="mt-5 space-y-4 opacity-90">
              {mission.map((m) => <p key={m.slice(0, 32)}>{m}</p>)}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-secondary/50 py-20">
        <div className="mx-auto max-w-7xl px-5">
          <p className="eyebrow">Our core values</p>
          <h2 className="mt-3 text-4xl">What we stand for</h2>
          <div className="mt-12 grid gap-5 md:grid-cols-2">
            {coreValues.map((v, i) => (
              <div key={v.title} className="rounded-2xl bg-card p-8 transition hover:-translate-y-1 hover:shadow-soft">
                <span className="font-display text-3xl text-primary">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="mt-3 text-2xl">{v.title}</h3>
                <p className="mt-3 text-muted-foreground">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}
