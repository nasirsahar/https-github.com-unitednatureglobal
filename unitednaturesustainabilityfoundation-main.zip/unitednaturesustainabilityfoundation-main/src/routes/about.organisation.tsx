import { createFileRoute, Link } from "@tanstack/react-router";
import education from "@/assets/education.jpg";
import { CTA, PageHero, meta } from "@/components/site";
import { organisationIntro, organisationParts } from "@/lib/content";

export const Route = createFileRoute("/about/organisation")({
  head: () => meta("How We Are Organized — United Nature Sustainability Foundation", "United Nature is organized through a Global Advisory Board, Board of Governors, Board of Directors and a Management leadership and executive team."),
  component: Organisation,
});

function Organisation() {
  return (
    <>
      <PageHero
        compact
        eyebrow="Who we are · Organisation"
        title="How We Are Organized"
        text="A non-profit entity built on governance, stewardship and delivery — from advisory and governing boards down to field teams, volunteers and partners."
        image={education}
      />

      <section className="mx-auto max-w-5xl px-5 py-20">
        <p className="text-lg leading-relaxed text-muted-foreground">{organisationIntro}</p>
        <div className="mt-12 grid gap-5 sm:grid-cols-2">
          {organisationParts.map((p, i) => (
            <Link key={p.title} to={p.to} className="group rounded-2xl border bg-card p-8 transition hover:-translate-y-1 hover:shadow-soft">
              <span className="font-display text-3xl text-primary">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="mt-3 text-2xl">{p.title}</h3>
              <p className="mt-3 text-muted-foreground">{p.text}</p>
              <span className="mt-5 inline-block font-semibold text-primary">Explore →</span>
            </Link>
          ))}
        </div>
      </section>

      <CTA />
    </>
  );
}
